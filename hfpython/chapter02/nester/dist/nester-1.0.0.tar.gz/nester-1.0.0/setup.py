from distutils.core import setup

setup(
	name = 'nester',
	version = '1.0.0',
	py_modules = ['nester'],
	author = 'Esteban Borai',
	author_email = 'estebanborai@outlook.com',
	url = 'https://github.com/estebanborai/learn-python',
	description = 'A simple function that takes a list and print items inside the list recursively'
)
